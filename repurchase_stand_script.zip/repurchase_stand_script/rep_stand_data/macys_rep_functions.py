import pandas as pd

def arrange(main_data):
    
    main_data['cid']=main_data.cid.astype("str")
    main_data['upc']=main_data.upc.astype("str")

    for col in['r_dt','r_amt','prc','qty','amt','r_qty','dt']:
        main_data[col].replace("(null)",'',inplace=True)

    for col in ['r_qty','r_amt','amt','qty','prc']:      
        main_data[col]=pd.to_numeric(main_data[col])

    main_data.drop(['MDSE_DEPT_NBR','BUYER_ID','PARENT_MDSE_DIVN_ID','GMM_ID'],axis=1,inplace=True)
    main_data['dt'] = pd.to_datetime(main_data['dt'])         ### change the date format ##
    main_data['r_dt'] = pd.to_datetime(main_data['r_dt'])


    count_data = main_data.groupby(['cid','upc']).size().reset_index(None) ## grouping the data by cid,upc & taken only two transactions(for same cid,same upc)##
    count_data.columns = ['cid','upc','count']
    count_2 = count_data[count_data['count']==2]
    ids = count_2.cid+'_'+count_2.upc
    main_data['new_id'] = main_data.cid+"_"+main_data.upc
    main_data_new = main_data.loc[main_data.new_id.isin(ids)]
    print("shape of data after taking count as 2",main_data_new.shape)

    main_data_new = main_data_new.sort_values(by=['cid','upc','dt']).reset_index(None) ## sorting ##
    main_data_new_copy = main_data_new.copy(deep=True)                                ### taking copy of the sorted data , in order to shift one row above ##
    main_data_new_copy = main_data_new_copy.shift(-1)

    main_data_new_copy.rename(columns={'r_dt':'r_dt_new','prc':'prc_new','amt':'amt_new','r_qty':'r_qty_new','amt':'amt_new',
                                       'oid':'oid_new','qty':'qty_new','r_amt':'r_amt_new','dt':'buy_dt_new'},inplace=True)
    main_data_new.rename(columns={'r_dt':'r_dt_old','prc':'prc_old','amt':'amt_old','r_qty':'r_qty_old','amt':'amt_old',
                                  'oid':'oid_old','qty':'qty_old','r_amt':'r_amt_old','dt':'buy_dt_old'},inplace=True)
    main_data_new.drop(['GMM_DESC','PROD_TYP_DESC','PARENT_MDSE_DIVN_DESC'],axis=1,inplace=True)

    main_data_new_copy.drop(['cid','upc'],axis=1,inplace= True)
    final = pd.concat([main_data_new,main_data_new_copy],axis=1)
    final=final.reset_index()
    del_cols = ['index','new_id']
    final.drop(del_cols,axis=1,inplace=True)
    final = final.iloc[::2]
    print("shape of the sales data after transformation",final.shape)

    #################------------------------- Deriving variables ------------------------------ ####################
    final['time_to_new_purchase']=(final['buy_dt_new']-final['buy_dt_old']).dt.days
    final['prc_chg_dollar']=final['prc_new']-final['prc_old']
    final['prc_chg_pct']=final['prc_chg_dollar']/final['prc_new']
    final['prc_chg_per_day']=final['prc_chg_dollar']/(final['time_to_new_purchase']+1)

    final['return_duration_from_recent_buy']=np.nan
    final['return_status']='N'
    final['returned_old_flag']='N'
    final['return_status_repurchase']=0

    final.loc[(np.isnan(final.r_qty_new) & np.isnan(final.r_qty_old)),['return_status','return_status_repurchase']]=['Both Kept',0]  
    final.loc[(final.r_qty_new>0) & (final.r_qty_old>0),['return_status','return_status_repurchase']] = ['Both Returned',1]
    final.loc[np.isnan(final.r_qty_new) & (final.r_qty_old>=0),['return_status']] = ['Returned Old']
    indexes = final.loc[(final.r_dt_old != "") & (final.buy_dt_new > final.r_dt_old),].index
    final.loc[indexes,'return_duration_from_recent_buy'] = (final.loc[indexes,'r_dt_old']-final.loc[indexes,'buy_dt_new']).dt.days
    final.loc[indexes,'returned_old_flag']="Y"
    final.loc[indexes,'return_status_repurchase']=0

    indexes_not=final.loc[pd.notnull(final.r_dt_old) & (final.buy_dt_new <=final.r_dt_old),].index
    final.loc[indexes_not,'return_duration_from_recent_buy'] = (final.loc[indexes_not,'r_dt_old']-          final.loc[indexes_not,'buy_dt_new']).dt.days
    final.loc[indexes_not,'returned_old_flag']="N"
    final.loc[indexes_not,'return_status_repurchase']=1

    final.loc[(final.r_qty_new>=0) & np.isnan(final.r_qty_old),['return_status','return_status_repurchase']]=['Returned_New',1]   
    final.drop(['return_status','return_duration_from_recent_buy','PROD_TYP_DESC','PROD_DESC','BRND_NM','VND_NM','BUYER_DESC',
                'MDSE_DEPT_DESC','LBL_NM'],axis=1,inplace=True)
    
    return(final)
